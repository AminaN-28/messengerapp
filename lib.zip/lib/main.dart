import 'package:flutter/material.dart';
import 'package:messenger_app/App.dart';

void main() {
  runApp(App());
}
