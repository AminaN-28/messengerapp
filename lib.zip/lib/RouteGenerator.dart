
import 'package:flutter/material.dart';

import 'Screens/DetailScreen.dart';
import 'Screens/HomeMessage.dart';
import 'Screens/LoginScreen.dart';

class RouteGenerator {
  static const String loginScreen = "/";

  static const String homeScreen = "/homeScreen";
  static const String detailScreen = "/detailScreen";
  static Route<dynamic> generatorRoute(RouteSettings settings) {
    switch (settings.name) {
      case loginScreen:
        return MaterialPageRoute(builder: (context) => LoginScreen());
      case homeScreen:
        return MaterialPageRoute(builder: (context) => HomeMessage());
      case detailScreen:
        return MaterialPageRoute(builder: (context) => DetailScreen());
      default:
        {
          return MaterialPageRoute(builder: (context) => null);
        }
    }
  }
}
