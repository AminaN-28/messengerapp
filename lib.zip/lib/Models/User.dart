class User {
  String userName;
  String urlImage;

  User(this.userName, this.urlImage);
  
}
