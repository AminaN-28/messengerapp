class Message {
  String message;
  bool isMe;
  String dateTime;

  Message(this.message, this.isMe, this.dateTime);
  
}
