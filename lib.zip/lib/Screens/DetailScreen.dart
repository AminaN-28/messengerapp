import 'package:flutter/material.dart';
import 'package:messenger_app/Widgets/BottomWidget.dart';
import 'package:messenger_app/Widgets/Memessage.dart';

class DetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            },
            color: Colors.grey.withOpacity(0.8),
          ),
          title: Row(
            children: [
              SizedBox(
                width: 20,
              ),
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        image: NetworkImage(
                            "https://pbs.twimg.com/profile_images/1119734856404090881/jhvo_wO6_400x400.jpg"))),
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Amina",
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  Text("En ligne",
                      style: TextStyle(
                          fontSize: 12, color: Colors.black.withOpacity(0.5)))
                ],
              )
            ],
          ),
        ),
        body: ListView.builder(
            itemCount: 5,
            itemBuilder: (context, int position) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Memessage(
                  isMe: position % 2 == 0,
                ),
              );
            }),
            bottomSheet:BottomWidget(),
            );
  }
}
