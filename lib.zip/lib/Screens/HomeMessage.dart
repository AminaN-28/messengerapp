import 'package:flutter/material.dart';
import 'package:messenger_app/Widgets/AppBarMessenger.dart';
import 'package:messenger_app/Widgets/CustomTextField.dart';
import 'package:messenger_app/Widgets/ListViewAllContact.dart';

class HomeMessage extends StatefulWidget {
  @override
  _HomeMessageState createState() => _HomeMessageState();
}

class _HomeMessageState extends State<HomeMessage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
     body: Padding(
       padding: const EdgeInsets.all(8.0),
       child: Column(
         children: [
           AppBarMessenger(),
           SizedBox(
             height: 10,
           ),
           CustomTextField(), // voir definition
           SizedBox(
             height: 30,
           ),

           Expanded(
             child: ListViewAllContact() // voir definition
          )
         ],
       ),
       )
    );
  }
}