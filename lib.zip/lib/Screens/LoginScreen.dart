import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  GlobalKey<FormState> key = GlobalKey<FormState>();
  TextEditingController textEditingController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Center(
        child: Column(
          children: [
            //le Widget Form nous permet de gerer les conditions que les for
            //-mulaires doivent respecter (Remplace alors les boucle if)
            CircleAvatar(
              radius: 50,
            ),
            SizedBox(
              height: 20,
            ),
            Form(
                key: key,
                child: Column(
                  children: [
                    TextFormField(
                      //onSaved on l'utilise pour
                      //onChanged on l'utilise si on veut pas
                      // utiliser TextEditingController, il nous donne directement le text
                      //keyboardType :TextInputType pour preciser le type de l'input
                      keyboardType: TextInputType.emailAddress,
                      validator: (String value) {
                        if (!value.contains("@")) {
                          return "Invalid Mail";
                        }
                        return null;
                        // si cela return null ca veut dire qu'il ya pas d'erreur
                
                      },
                    ),
                    TextFormField(
                        controller: textEditingController,
                        validator: (String mdp) {
                          if (mdp.length < 6) {
                            return "Error";
                          }
                          return null;
                        },
                        onChanged: (String value){

                        },
                     ),
                      TextFormField(
                        validator: (String mdpconfirm) {
                          // ignore: unrelated_type_equality_checks
                          if (mdpconfirm != textEditingController.text) {
                            return "ERROR";
                          }
                          return null;
                        },
                      )
                  ],
                ),
                ),
                TextButton(
                    onPressed: () {
                      //recuperer tous emails et on valide tt le formulaire
                      if (key.currentState.validate()) {
                        print("OK");
                      }
                    },
                    child: Text("LOGIN"),
                  )
          ],
        ),
      ),
    );
  }
}
