import 'package:flutter/material.dart';
import 'package:messenger_app/RouteGenerator.dart';

import 'OneRowContactMessage.dart';


class ListViewAllContact extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (BuildContext context, int index) 
      { 
        return GestureDetector(
          onTap: (){
            Navigator.pushNamed(context, RouteGenerator.detailScreen);
          },
          child: OneRowContactMessage());
      },
      itemCount: 20,
    );
  }
  
}