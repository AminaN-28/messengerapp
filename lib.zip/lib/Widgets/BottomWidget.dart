import 'package:flutter/material.dart';

class BottomWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      width: double.infinity,
      decoration: BoxDecoration(
        color :Colors.grey.withOpacity(0.1)
      ),
      child:Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Container(
            width: (MediaQuery.of(context).size.width)/5 ,
            child: Row(
              children: <Widget>[
                Icon(Icons.camera_alt, size: 30,color:Colors.lightBlue),
                SizedBox(width: 15,),
                Icon(Icons.keyboard_voice,size: 30,color: Colors.lightBlue,)
              ],
            ),
          ),
          Container(
            width: (MediaQuery.of(context).size.width)/1.5,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:<Widget>[
                Container(
                 width: (MediaQuery.of(context).size.width)/1.8,
                 height: 40,
                 decoration: BoxDecoration(
                   color: Colors.grey,
                   borderRadius: BorderRadius.circular(20)
                 ),
                 child: Padding(
                   padding: const EdgeInsets.only(left:12),
                   child: TextField(
                     
                     decoration: InputDecoration(
                       border: InputBorder.none,
                       hintText: "Message",
                     ),
                   ),
                   ),                   
                ),
                SizedBox(width: 15,
                ),
                Icon(Icons.send , size: 30,color: Colors.lightBlue,),
              ],
            ),
          ),
        ],
      )
    );
  }
}