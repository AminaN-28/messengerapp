import 'package:flutter/material.dart';
import 'package:messenger_app/Widgets/CircularImageUser.dart';

class OneRowContactMessage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom:10.0),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(right:10.0),
            child: CircularImageUser(urlImage: "https://pbs.twimg.com/profile_images/1119734856404090881/jhvo_wO6_400x400.jpg"
            , radius: 60),
            ),

          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Text("Amina", style: TextStyle(
               fontSize: 18,
               fontWeight: FontWeight.bold
             ),),
             SizedBox(
               height: 5,
             ),
             Container(
               width: MediaQuery.of(context).size.width - 115,
               child: Text("Flutter is better than React Flutter is better than React Flutter is better than React Flutter is better than React 19h00",
               style: TextStyle(fontSize: 15,),
               overflow: TextOverflow.ellipsis,
               maxLines: 1,
               ),)
           ],
          )
        ],
      ), 
    );
  }
}
