import 'package:flutter/material.dart';
import 'package:messenger_app/RouteGenerator.dart';

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: RouteGenerator.homeScreen,
      onGenerateRoute: RouteGenerator.generatorRoute,
      theme: ThemeData(
        primaryColor: Colors.white,
        
      ),
    );
  }
}